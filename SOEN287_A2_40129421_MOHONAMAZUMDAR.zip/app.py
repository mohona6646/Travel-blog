from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def base():
    return render_template("base.html")


@app.route("/Thailand/")
def thailand():
    return render_template("Thailand.html")


@app.route("/Morocco/")
def morocco():
    return render_template("Morocco.html")


@app.route("/Japan/")
def japan():
    return render_template("Japan.html")


@app.route("/Travel/")
def travel():
    return render_template("travel.html")


@app.route("/Contacts/")
def contact():
    return render_template("contacts.html")


if __name__ == '__main__':
    app.jinja_env.auto_reload = True
    app.run(debug=True)
